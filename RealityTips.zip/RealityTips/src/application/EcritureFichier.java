package application;
import java.io.*;
public class EcritureFichier {
		public static void main(String args , int line) {
		try {
			File fichier = new File ("monFichier.txt");
			FileWriter writer = new FileWriter(fichier);
			if (line == (-1)) {
			for (int i = 0; i < 1; i++) {
				writer.write(args + " ");
				writer.write("\n");
				System.out.println("date bien ajouté");
				}
			}
			/*else {  // Doublon détecté
				for (int i = 0; i < line; i++) {
					bw.newLine();
					}
				bw.write(LectureFichier.main("22-01-2010"));
				
			}*/
			writer.close();
			} catch (FileNotFoundException e) {
					e.printStackTrace();
			} catch (IOException e) {
					e.printStackTrace();
				}

	}
}

