package application;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class LectureFichier {
	  public static int main(String args) {  
		  int lineToReturn = -1;
		  
		  try {
			  int line=0;
			  File myObj = new File("monFichier.txt");
			  Scanner myReader = new Scanner(myObj);  
			  while (myReader.hasNextLine()) {
				  String data = myReader.nextLine();
				  System.out.println(data);
				  if (data.startsWith(args)) {
					  lineToReturn = line;
				  }
				  line=line+1;
			  }
			  myReader.close();
		  } catch (FileNotFoundException e) {
			  System.out.println("An error occurred.");
			  e.printStackTrace();
		  }
		  return lineToReturn;
	  }
	} 