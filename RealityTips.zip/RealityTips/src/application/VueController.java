package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VueController {
	
	@FXML
	private Label TotalPerPerson;
	
	@FXML
	private Label TipPerPerson;
	
	@FXML
	private TextField DateCalculInput;
	
	@FXML
	private Label ErrorMessage;
	
	@FXML
	private Button Calculate;
	
	@FXML
	private TextField BillInput;
	@FXML
	private TextField TipPercentInput;
	@FXML
	private TextField NbPeopleInput;
	
	int bill;
	int tipPercent;
	int nbPeople;
	double total;
	double tippp;
	String chaine;
	
	public void calculate(ActionEvent e) {
		
		
		
		try {
			init(); 
							
				bill = Integer.parseInt(BillInput.getText());
				tipPercent = Integer.parseInt(TipPercentInput.getText());
				nbPeople = Integer.parseInt(NbPeopleInput.getText());
				
				isNegative(bill);
				isNegative(tipPercent);
				isNegative(nbPeople);
				zero(nbPeople);
				check(DateCalculInput.getText());
				
				chaine= DateCalculInput.getText()+" ;" + BillInput.getText() +" ;"+  TipPercentInput.getText() +" ;"+ NbPeopleInput.getText();
				
				EcritureFichier.main(chaine,LectureFichier.main(DateCalculInput.getText()));
				
				
				tippp = ((bill / nbPeople) * tipPercent)/100;
				total = bill / nbPeople + tippp;
				
			
			}
		catch (NumberFormatException e1) {
			ErrorMessage.setText(e1.getMessage());
		}
		catch (IndexOutOfBoundsException e1) {
			ErrorMessage.setText(e1.getMessage());
		} 
		
		
		TipPerPerson.setText(String.valueOf(tippp));
		TotalPerPerson.setText(String.valueOf(total));
		}
		
	

		private void  isNegative(int number) throws IndexOutOfBoundsException {
			if (number<0) {
				
				
				throw new IndexOutOfBoundsException("Vous ne pouvez pas être moins que 0 logiquement");
				}
		}
		
		private void zero(int number) throws IndexOutOfBoundsException {
			if (number==0) {
				throw new IndexOutOfBoundsException("Vous ne pouvez pas diviser par 0");
				}
		}
		
		
		
		public void check(String date) throws IndexOutOfBoundsException {
		      SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		      format.setLenient(false);  
		      try
		      {
		          Date d = format.parse(date);  //Verif si date
		      }
		      catch (ParseException e)
		      {
		          throw new IndexOutOfBoundsException("VEUILLEZ RESPECTER LE FORMAT DE DATE");
		      }

		   }

		
		private void init(){
			ErrorMessage.setText("");
		}

}


